
(function(){
const $=id=>document.getElementById(id);
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const amount=n=>Number(n||0).toLocaleString('th-TH')+' ฿';
let chosenRoom='';
function refresh(){
 if(!$('vipAdminCards')||typeof offlineAdminEvents==='undefined')return;
 const records=offlineAdminEvents||[];
 const rooms=[...new Set(records.map(e=>e.room_code).filter(Boolean))];
 if(typeof roomCode!=='undefined'&&roomCode&&!rooms.includes(roomCode))rooms.push(roomCode);
 const betRows=records.filter(e=>e.event==='BET_PLACED');
 const rounds=records.filter(e=>e.event==='ROUND_RESULT');
 const betAmount=betRows.reduce((a,e)=>a+Number(e.bet_amount||0),0);
 const totalPaid=rounds.reduce((a,e)=>a+Number(e.payout||0),0);
 const values=[
  ['จำนวนผู้เล่นทั้งหมด','—','ไม่มีข้อมูลข้ามเครื่อง'],
  ['จำนวนผู้เล่นออนไลน์','—','ไม่มีเซิร์ฟเวอร์สถานะออนไลน์'],
  ['จำนวนบอททั้งหมด','—','ตรวจสอบทุกห้องไม่ได้'],
  ['จำนวนห้องเกมทั้งหมด',rooms.length,'เฉพาะห้องที่รู้จักในพรีวิว'],
  ['จำนวนห้องที่กำลังใช้งาน','—','ไม่มีสถานะห้องจากเซิร์ฟเวอร์'],
  ['จำนวนรอบเกมทั้งหมด',rounds.length,'เฉพาะรอบที่บันทึกในพรีวิว'],
  ['จำนวนการเดิมพันทั้งหมด',betRows.length,'เฉพาะรายการที่บันทึกในพรีวิว'],
  ['ยอดเดิมพันรวมทุกห้อง',amount(betAmount),'รวมเฉพาะประวัติในเครื่องนี้'],
  ['ประวัติการเล่นและกิจกรรม',records.length,'จำนวนเหตุการณ์ในประวัติพรีวิว']
 ];
 $('vipAdminCards').innerHTML=values.map(([key,val,note])=>'<div class="vip-admin-card"><small>'+esc(key)+'</small><strong class="'+(val==='—'?'admin-unavailable':'')+'">'+esc(val)+'</strong><span class="admin-card-note">'+esc(note)+'</span></div>').join('');
 if(!chosenRoom||!rooms.includes(chosenRoom))chosenRoom=rooms[0]||'';
 $('vipAdminRooms').innerHTML=rooms.length?rooms.map(r=>'<button type="button" data-vip-room="'+esc(r)+'">◉ '+esc(r)+' • พรีวิว</button>').join(''):'<small>ยังไม่มีห้องทดลอง</small>';
 $('vipAdminRooms').querySelectorAll('button').forEach(button=>button.onclick=()=>{chosenRoom=button.dataset.vipRoom;refresh()});
 const local=records.filter(e=>e.room_code===chosenRoom);
 const recent=local.filter(e=>e.event==='ROUND_RESULT').slice(-1)[0];
 $('vipAdminRoomInfo').innerHTML='<div class="vip-room-detail"><span>Room Code</span><b>'+esc(chosenRoom||'—')+'</b><span>โหมดล่าสุด</span><b>'+esc(local.at(-1)?.mode||'—')+'</b><span>รอบล่าสุด</span><b>'+esc(recent?.round_id||'—')+'</b><span>ผลลูกเต๋า</span><b>'+esc(recent?[recent.dice_1,recent.dice_2,recent.dice_3].join(' - '):'—')+'</b><span>แต้มรวม</span><b>'+esc(recent?.dice_total??'—')+'</b></div>';
 $('vipAdminRecent').innerHTML=local.length?local.slice(-8).reverse().map(e=>'<div>'+esc(e.timestamp?.slice(11,19)||'')+' · '+esc(e.event)+' · '+esc(e.player_name||'')+' '+esc(e.bet_type||'')+'</div>').join(''):'<div>ยังไม่มีกิจกรรมในห้องนี้</div>';
}
const prior=window.renderOfflineAdmin;
if(typeof prior==='function')window.renderOfflineAdmin=function(){prior();refresh();};
setInterval(()=>{if($('adminPreview')?.classList.contains('active'))refresh()},1500);
})();
