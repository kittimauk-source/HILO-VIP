
/* This is an offline visual preview, not a server administration or authorization API. */
(function(){
  'use strict';
  const id=x=>document.getElementById(x);
  const button=id('offlineAdminClear');
  if(!button)return;
  button.addEventListener('click',()=>{
    if(!id('adminPreview')?.classList.contains('active')||window.__hiloAdminPreviewAuthorized!==true)return;
    modal('ยืนยันการล้างข้อมูล',
      '<p>คุณต้องการล้างข้อมูลประวัติและสถิติในระบบหลังบ้านใช่หรือไม่? การดำเนินการนี้ไม่สามารถย้อนกลับได้</p>'+
      '<p class="demo-note">เฉพาะประวัติพรีวิวในเบราว์เซอร์นี้เท่านั้น บัญชี ยอดคงเหลือ ห้องปัจจุบัน และรายการที่ยังไม่สิ้นสุดจะไม่ถูกลบ</p>'+
      '<div class="admin-clear-confirm"><button type="button" id="adminClearCancel" class="btn alt">ยกเลิก</button><button type="button" id="adminClearConfirm" class="btn admin-clear-btn">ยืนยันการล้างข้อมูล</button></div>');
    id('adminClearCancel').addEventListener('click',()=>id('closeModal').click(),{once:true});
    id('adminClearConfirm').addEventListener('click',()=>{
      if(!id('adminPreview')?.classList.contains('active')||window.__hiloAdminPreviewAuthorized!==true){id('closeModal').click();return;}
      const confirmedRounds=new Set(offlineAdminEvents
        .filter(e=>e.event==='ROUND_RESULT')
        .map(e=>String(e.room_code)+'::'+String(e.round_id)));
      /* Never delete entries representing a placed but not-yet-settled bet. */
      const pending=offlineAdminEvents.filter(e=>e.event==='BET_PLACED' &&
        !confirmedRounds.has(String(e.room_code)+'::'+String(e.round_id)));
      offlineAdminEvents.splice(0,offlineAdminEvents.length,...pending);
      offlineCellHistory.length=0;
      /* Persist empty chat logs rather than removing their key: the original chat
         component falls back to its in-memory copy when a key is absent. */
      try{
        for(let n=sessionStorage.length-1;n>=0;n--){
          const key=sessionStorage.key(n);
          if(key&&key.startsWith('hilo-demo-chat-'))sessionStorage.setItem(key,'[]');
        }
        if(typeof roomCode==='string'&&roomCode)sessionStorage.setItem('hilo-demo-chat-'+roomCode,'[]');
      }catch(_){ /* Private browsing may block storage; other local events still clear. */ }
      /* Render the existing dashboard sections in place; do not reload the game. */
      renderOfflineAdmin();
      id('demoDiceLog')?.replaceChildren();
      id('demoChatLog')?.replaceChildren();
      id('closeModal').click();
    },{once:true});
  });
})();
